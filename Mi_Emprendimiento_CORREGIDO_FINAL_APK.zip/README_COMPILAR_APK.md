# Mi Emprendimiento — versión 1.1

Esta es la nueva versión de prueba de la aplicación. Mantiene el proyecto Android nativo y agrega una primera versión completa del mapa funcional que definimos a partir de la app anterior.

## Incluye
- Inicio con resumen de caja, stock bajo, productos y movimientos.
- Caja: ingresos/gastos, efectivo, caja chica y banco, categorías.
- Materiales: stock mínimo, costo unitario, compras y pérdidas.
- Productos: precio, mano de obra, otros costos, margen y recetas.
- Producción: consume automáticamente la receta y aumenta el stock terminado.
- Ventas: descuenta stock y registra el ingreso en la cuenta elegida.
- Herramientas: valor de compra, usos estimados y costo por uso.
- Calculadora de precios.
- Informes y alertas.
- Notas persistentes.
- Menú lateral y navegación inferior.
- Migración de base de datos de v1 a v1.1 para conservar datos existentes.

## Compilación
El repositorio actual del proyecto usa GitHub Actions con Java 17 y Gradle 8.9.
El workflow busca el ZIP, lo descomprime y genera `app-debug.apk`.

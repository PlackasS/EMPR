# Mi Emprendimiento — versión CORREGIDA 2

Proyecto Android listo para compilar mediante GitHub Actions.

## Corrección principal
Se unificó el objetivo JVM de Java y Kotlin en **17** para evitar el error:
`Inconsistent JVM-target compatibility detected for tasks compileDebugJavaWithJavac (1.8) and kspDebugKotlin (17)`.

## Flujo
1. Subir el contenido del proyecto al repositorio de GitHub.
2. GitHub Actions ejecuta Gradle 8.9 con Java 17.
3. Se genera `app-debug.apk`.
4. El APK queda disponible como artefacto de la ejecución.

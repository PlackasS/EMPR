package com.emprendimiento.app

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.room.withTransaction
import com.emprendimiento.app.data.*
import com.emprendimiento.app.ui.theme.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(this)
        setContent { EmprendimientoTheme { App(db) } }
    }
}

private data class NavItem(val key: String, val label: String, val icon: @Composable () -> Unit)

@Composable
fun App(db: AppDatabase) {
    var screen by remember { mutableStateOf("home") }
    var menuOpen by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val inventory by db.inventoryDao().observeAll().collectAsState(initial = emptyList())
    val low by db.inventoryDao().observeLowStock().collectAsState(initial = emptyList())
    val materials by db.inventoryDao().observeType(ItemType.MATERIAL).collectAsState(initial = emptyList())
    val tools by db.inventoryDao().observeType(ItemType.TOOL).collectAsState(initial = emptyList())
    val products by db.productDao().observeAll().collectAsState(initial = emptyList())
    val movements by db.movementDao().observeAll().collectAsState(initial = emptyList())
    val income by db.movementDao().observeIncome().collectAsState(initial = 0.0)
    val expenses by db.movementDao().observeExpenses().collectAsState(initial = 0.0)

    val nav = listOf(
        NavItem("home", "Inicio") { Icon(Icons.Default.Home, null) },
        NavItem("finance", "Caja") { Icon(Icons.Default.AttachMoney, null) },
        NavItem("stock", "Stock") { Icon(Icons.Default.Inventory2, null) },
        NavItem("products", "Productos") { Icon(Icons.Default.ShoppingBag, null) },
        NavItem("more", "Más") { Icon(Icons.Default.MoreHoriz, null) }
    )

    ModalNavigationDrawer(
        drawerState = androidx.compose.material3.rememberDrawerState(if (menuOpen) DrawerValue.Open else DrawerValue.Closed),
        gesturesEnabled = true,
        drawerContent = {
            ModalDrawerSheet(containerColor = Cream) {
                Spacer(Modifier.height(28.dp))
                Text("Mi Emprendimiento", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(horizontal = 24.dp))
                Text("Administración completa", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp))
                Spacer(Modifier.height(16.dp))
                DrawerButton("Inicio", Icons.Default.Home) { screen="home"; menuOpen=false }
                DrawerButton("Caja y movimientos", Icons.Default.AccountBalanceWallet) { screen="finance"; menuOpen=false }
                DrawerButton("Materiales y stock", Icons.Default.Inventory2) { screen="stock"; menuOpen=false }
                DrawerButton("Productos y recetas", Icons.Default.ShoppingBag) { screen="products"; menuOpen=false }
                DrawerButton("Producción", Icons.Default.BuildCircle) { screen="production"; menuOpen=false }
                DrawerButton("Ventas", Icons.Default.PointOfSale) { screen="sales"; menuOpen=false }
                DrawerButton("Herramientas", Icons.Default.Handyman) { screen="tools"; menuOpen=false }
                DrawerButton("Calculadora de precios", Icons.Default.Calculate) { screen="calculator"; menuOpen=false }
                DrawerButton("Informes", Icons.Default.BarChart) { screen="reports"; menuOpen=false }
                DrawerButton("Notas", Icons.Default.Notes) { screen="notes"; menuOpen=false }
                Spacer(Modifier.weight(1f))
                DrawerButton("Guardar / respaldo", Icons.Default.Save) { Toast.makeText(ctx, "Los datos se guardan automáticamente en el teléfono", Toast.LENGTH_LONG).show(); menuOpen=false }
                DrawerButton("Configuración", Icons.Default.Settings) { screen="settings"; menuOpen=false }
                Spacer(Modifier.height(16.dp))
            }
        }
    ) {
        Scaffold(
            containerColor = Cream,
            topBar = {
                SmallTopAppBar(
                    title = { Text(titleFor(screen), fontWeight = FontWeight.SemiBold) },
                    navigationIcon = { IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.Menu, "Menú") } }
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Cream) {
                    nav.forEach { item ->
                        NavigationBarItem(
                            selected = screen == item.key,
                            onClick = { screen = item.key },
                            icon = item.icon,
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        ) { padding ->
            when(screen) {
                "home" -> Home(income, expenses, low, products, inventory, movements, padding, scope)
                "finance" -> Finance(movements, scope, db, padding)
                "stock" -> Stock(materials, scope, db, padding)
                "products" -> Products(products, materials, tools, db, scope, padding)
                "production" -> Production(products, materials, db, scope, padding)
                "sales" -> Sales(products, db, scope, padding)
                "tools" -> Tools(tools, db, scope, padding)
                "calculator" -> Calculator(products, materials, tools, db, scope, padding)
                "reports" -> Reports(income, expenses, movements, low, products, padding)
                "notes" -> Notes(ctx, padding)
                "settings" -> Settings(padding)
                else -> Home(income, expenses, low, products, inventory, movements, padding, scope)
            }
        }
    }
}

@Composable private fun DrawerButton(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    NavigationDrawerItem(label={Text(text)}, selected=false, onClick=onClick, icon={Icon(icon,null)}, modifier=Modifier.padding(horizontal=12.dp, vertical=2.dp))
}

private fun titleFor(screen: String) = when(screen) {
    "home" -> "Mi Emprendimiento"
    "finance" -> "Caja y movimientos"
    "stock" -> "Materiales y stock"
    "products" -> "Productos y recetas"
    "production" -> "Producción"
    "sales" -> "Ventas"
    "tools" -> "Herramientas"
    "calculator" -> "Calculadora de precios"
    "reports" -> "Informes"
    "notes" -> "Notas"
    "settings" -> "Configuración"
    else -> "Mi Emprendimiento"
}

@Composable
private fun Home(income: Double, expenses: Double, low: List<InventoryItem>, products: List<Product>, inventory: List<InventoryItem>, movements: List<Movement>, padding: PaddingValues, scope: CoroutineScope) {
    LazyColumn(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Tu negocio, en orden", style=MaterialTheme.typography.headlineMedium, fontWeight=FontWeight.Bold)
            Text("Una vista rápida de caja, stock y ventas", color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                MetricCard("Ingresos", money(income), Sage.copy(alpha=.55f), Modifier.weight(1f))
                MetricCard("Gastos", money(expenses), Blush, Modifier.weight(1f))
            }
        }
        item { MetricCard("Resultado de caja", money(income-expenses), Lavender, Modifier.fillMaxWidth()) }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                MetricCard("Productos", products.size.toString(), Butter, Modifier.weight(1f))
                MetricCard("Movimientos", movements.size.toString(), Sage.copy(alpha=.35f), Modifier.weight(1f))
            }
        }
        if (low.isNotEmpty()) item {
            Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFFFE9D6)), modifier=Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("⚠️ Stock bajo", fontWeight=FontWeight.Bold)
                    low.take(5).forEach { Text("• ${it.name}: ${qty(it.quantity)} ${it.unit} (mín. ${qty(it.minimumStock)})") }
                }
            }
        }
        item {
            SectionTitle("Accesos rápidos")
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                ActionCard("Venta", Icons.Default.PointOfSale, Modifier.weight(1f)) { }
                ActionCard("Compra", Icons.Default.AddShoppingCart, Modifier.weight(1f)) { }
                ActionCard("Producción", Icons.Default.BuildCircle, Modifier.weight(1f)) { }
            }
            Text("Usá el menú ☰ para entrar a estas funciones.", color=MaterialTheme.colorScheme.onSurfaceVariant, modifier=Modifier.padding(top=6.dp))
        }
    }
}

@Composable private fun MetricCard(title:String, value:String, color:Color, modifier:Modifier) {
    Card(modifier=modifier, colors=CardDefaults.cardColors(containerColor=color)) { Column(Modifier.padding(16.dp)) { Text(title); Text(value, style=MaterialTheme.typography.titleLarge, fontWeight=FontWeight.Bold) } }
}

@Composable private fun ActionCard(text:String, icon:androidx.compose.ui.graphics.vector.ImageVector, modifier:Modifier, onClick:()->Unit) {
    Card(modifier=modifier, onClick=onClick, colors=CardDefaults.cardColors(containerColor=Color.White)) { Column(Modifier.padding(10.dp), horizontalAlignment=Alignment.CenterHorizontally) { Icon(icon,null); Spacer(Modifier.height(4.dp)); Text(text) } }
}

@Composable
private fun Finance(movements: List<Movement>, scope: CoroutineScope, db: AppDatabase, padding: PaddingValues) {
    var desc by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }; var category by remember { mutableStateOf("OTRO") }
    var account by remember { mutableStateOf(Account.EFECTIVO) }; var showAccount by remember { mutableStateOf(false) }; var showCategory by remember { mutableStateOf(false) }
    val income = movements.filter { it.type==MovementType.INCOME || it.type==MovementType.SALE }.sumOf { if(it.account==Account.EFECTIVO) it.amount else 0.0 }
    val expense = movements.filter { it.type !in listOf(MovementType.INCOME,MovementType.SALE,MovementType.PRODUCTION) && it.account==Account.EFECTIVO }.sumOf { it.amount }
    LazyColumn(Modifier.padding(padding).padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item {
            Text("Saldos de caja", style=MaterialTheme.typography.titleLarge)
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                MetricCard("Efectivo", money(income-expense), Sage.copy(alpha=.45f), Modifier.weight(1f))
                MetricCard("Banco", money(balance(movements,Account.BANCO)), Lavender, Modifier.weight(1f))
                MetricCard("Caja chica", money(balance(movements,Account.CAJA_CHICA)), Butter, Modifier.weight(1f))
            }
        }
        item {
            SectionTitle("Nuevo movimiento")
            OutlinedTextField(desc,{desc=it},label={Text("Descripción")},modifier=Modifier.fillMaxWidth(),singleLine=true)
            OutlinedTextField(amount,{amount=it},label={Text("Monto (CLP)")},modifier=Modifier.fillMaxWidth(),singleLine=true)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick={showAccount=true},modifier=Modifier.weight(1f)){Text(accountLabel(account))}
                OutlinedButton(onClick={showCategory=true},modifier=Modifier.weight(1f)){Text(category)}
            }
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Button(onClick={
                    amount.replace(".","").replace(",","").toDoubleOrNull()?.let { a -> scope.launch { db.movementDao().insert(Movement(type=MovementType.INCOME,description=desc.ifBlank{"Ingreso"},amount=a,account=account,category=category)); desc=""; amount="" } }
                },modifier=Modifier.weight(1f)){Text("+ Ingreso")}
                OutlinedButton(onClick={
                    amount.replace(".","").replace(",","").toDoubleOrNull()?.let { a -> scope.launch { db.movementDao().insert(Movement(type=MovementType.EXPENSE,description=desc.ifBlank{"Gasto"},amount=a,account=account,category=category)); desc=""; amount="" } }
                },modifier=Modifier.weight(1f)){Text("− Gasto")}
            }
        }
        item { SectionTitle("Últimos movimientos") }
        items(movements.take(60)) { m -> MovementRow(m) }
    }
    if(showAccount) SimpleChoiceDialog("Cuenta", Account.values().toList(), {accountLabel(it)}, {showAccount=false}) { account=it; showAccount=false }
    if(showCategory) SimpleChoiceDialog("Categoría", listOf("VENTAS","COMPRAS","TRANSPORTE","INSUMOS","MANO DE OBRA","OTROS"), {it}, {showCategory=false}) { category=it; showCategory=false }
}

private fun balance(movements:List<Movement>, account:Account):Double = movements.filter{it.account==account}.sumOf { if(it.type==MovementType.INCOME||it.type==MovementType.SALE) it.amount else if(it.type==MovementType.PRODUCTION) 0.0 else -it.amount }

@Composable private fun MovementRow(m:Movement) {
    ListItem(headlineContent={Text(m.description)}, supportingContent={Text("${date(m.dateMillis)} • ${accountLabel(m.account)} • ${m.category}")}, trailingContent={Text((if(m.type==MovementType.INCOME||m.type==MovementType.SALE) "+" else "−")+money(m.amount))})
    HorizontalDivider()
}

@Composable
private fun Stock(materials: List<InventoryItem>, scope: CoroutineScope, db: AppDatabase, padding: PaddingValues) {
    var showNew by remember { mutableStateOf(false) }
    var showPurchase by remember { mutableStateOf(false) }
    var showLoss by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<InventoryItem?>(null) }
    LazyColumn(Modifier.padding(padding).padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
        item {
            Text("Materiales e insumos", style=MaterialTheme.typography.titleLarge)
            Text("El stock se descuenta al producir y aumenta con las compras.", color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Button(onClick={showNew=true}, modifier=Modifier.weight(1f)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(4.dp));Text("Material")}
                OutlinedButton(onClick={showPurchase=true}, modifier=Modifier.weight(1f)){Icon(Icons.Default.AddShoppingCart,null);Spacer(Modifier.width(4.dp));Text("Compra")}
                OutlinedButton(onClick={showLoss=true}, modifier=Modifier.weight(1f)){Icon(Icons.Default.RemoveCircleOutline,null);Spacer(Modifier.width(4.dp));Text("Pérdida")}
            }
        }
        items(materials) { item ->
            Card(onClick={selected=item}, modifier=Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(containerColor=if(item.quantity<=item.minimumStock&&item.minimumStock>0) Color(0xFFFFE9D6) else Color.White)){
                ListItem(headlineContent={Text(item.name,fontWeight=FontWeight.SemiBold)},supportingContent={Text("${qty(item.quantity)} ${item.unit} • ${money(item.unitCost)}/u")},trailingContent={if(item.quantity<=item.minimumStock&&item.minimumStock>0)Text("⚠️")})
            }
        }
    }
    if(showNew) MaterialDialog(onDismiss={showNew=false}) { item -> scope.launch { db.inventoryDao().insert(item); showNew=false } }
    if(showPurchase) PurchaseDialog(materials,onDismiss={showPurchase=false}) { itemId, amount, cost, description -> scope.launch { db.withTransaction { db.inventoryDao().changeQuantity(itemId, amount); db.movementDao().insert(Movement(type=MovementType.MATERIAL_PURCHASE,description=description,amount=amount*cost,inventoryItemId=itemId,quantity=amount,category="COMPRAS")) }; showPurchase=false } }
    if(showLoss) LossDialog(materials,onDismiss={showLoss=false}) { itemId, amount, cost, description -> scope.launch { db.withTransaction { db.inventoryDao().changeQuantity(itemId, -amount); db.movementDao().insert(Movement(type=MovementType.LOSS,description=description,amount=amount*cost,inventoryItemId=itemId,quantity=amount,category="PÉRDIDA")) }; showLoss=false } }
    if(selected!=null) EditMaterialDialog(selected!!,onDismiss={selected=null},onSave={updated->scope.launch{db.inventoryDao().update(updated);selected=null}},onDelete={item->scope.launch{db.inventoryDao().delete(item);selected=null}})
}

@Composable private fun InventoryRow(item:InventoryItem) {
    Card(colors=CardDefaults.cardColors(containerColor=if(item.quantity<=item.minimumStock && item.minimumStock>0) Color(0xFFFFE9D6) else Color.White), modifier=Modifier.fillMaxWidth()) {
        ListItem(headlineContent={Text(item.name,fontWeight=FontWeight.SemiBold)}, supportingContent={Text("${qty(item.quantity)} ${item.unit} • $${String.format(Locale("es","CL"),"%,.0f",item.unitCost)}/u")}, trailingContent={if(item.quantity<=item.minimumStock&&item.minimumStock>0) Text("⚠️")})
    }
}

@Composable
private fun Products(products:List<Product>, materials:List<InventoryItem>, tools:List<InventoryItem>, db:AppDatabase, scope:CoroutineScope, padding:PaddingValues) {
    var showNew by remember{mutableStateOf(false)}; var selected by remember{mutableStateOf<Product?>(null)}
    LazyColumn(Modifier.padding(padding).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item { Text("Productos terminados",style=MaterialTheme.typography.titleLarge); Text("Cada producto puede tener receta, mano de obra, costos y margen.",color=MaterialTheme.colorScheme.onSurfaceVariant) }
        item { Button(onClick={showNew=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Add,null);Spacer(Modifier.width(6.dp));Text("Crear producto") } }
        items(products){p->
            Card(onClick={selected=p},modifier=Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color.White)){
                ListItem(headlineContent={Text(p.name,fontWeight=FontWeight.SemiBold)},supportingContent={Text("Venta ${money(p.salePrice)} • Costo base ${money(p.laborCost+p.otherCost)}")},trailingContent={Text("Stock ${qty(p.stock)}")})
            }
        }
    }
    if(showNew) ProductDialog(onDismiss={showNew=false},onSave={p->scope.launch{db.productDao().insert(p);showNew=false}})
    if(selected!=null) RecipeDialog(selected!!,materials,tools,db,scope){selected=null}
}

@Composable
private fun ProductDialog(onDismiss:()->Unit,onSave:(Product)->Unit){
    var name by remember{mutableStateOf("")};var price by remember{mutableStateOf("")};var labor by remember{mutableStateOf("")};var other by remember{mutableStateOf("")};var margin by remember{mutableStateOf("30")}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Nuevo producto")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(7.dp)){
        OutlinedTextField(name,{name=it},label={Text("Nombre")},singleLine=true)
        OutlinedTextField(price,{price=it},label={Text("Precio de venta")},singleLine=true)
        OutlinedTextField(labor,{labor=it},label={Text("Mano de obra por unidad")},singleLine=true)
        OutlinedTextField(other,{other=it},label={Text("Otros costos por unidad")},singleLine=true)
        OutlinedTextField(margin,{margin=it},label={Text("Margen objetivo %")},singleLine=true)
    }},confirmButton={Button(enabled=name.isNotBlank(),onClick={onSave(Product(name=name,salePrice=n(price),laborCost=n(labor),otherCost=n(other),marginPercent=n(margin)))} ){Text("Crear")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancelar")}})
}

@Composable
private fun RecipeDialog(product:Product,materials:List<InventoryItem>,tools:List<InventoryItem>,db:AppDatabase,scope:CoroutineScope,onClose:()->Unit){
    var selectedId by remember{mutableStateOf(materials.firstOrNull()?.id ?: 0)}; var q by remember{mutableStateOf("")}; var menu by remember{mutableStateOf(false)}
    val recipeState=remember{mutableStateListOf<ProductMaterial>()}
    LaunchedEffect(product.id){recipeState.clear();recipeState.addAll(db.productDao().recipe(product.id))}
    val matName={id:Long->materials.firstOrNull{it.id==id}?.name ?: "Material"}
    AlertDialog(onDismissRequest=onClose,title={Text("Receta: ${product.name}")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
        Text("Cantidad de material necesaria para 1 unidad",color=MaterialTheme.colorScheme.onSurfaceVariant)
        Box{OutlinedButton(onClick={menu=true},modifier=Modifier.fillMaxWidth()){Text(materials.firstOrNull{it.id==selectedId}?.name ?: "Elegir material")};DropdownMenu(expanded=menu,onDismissRequest={menu=false}){materials.forEach{m->DropdownMenuItem(text={Text(m.name)},onClick={selectedId=m.id;menu=false})}}}
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){OutlinedTextField(q,{q=it},label={Text("Cantidad")},modifier=Modifier.weight(1f),singleLine=true);Button(onClick={q.toDoubleOrNull()?.let{v->recipeState.add(ProductMaterial(productId=product.id,materialId=selectedId,quantity=v));q=""}}){Text("Agregar")}}
        recipeState.forEach{r->Text("• ${matName(r.materialId)}: ${qty(r.quantity)}")}
        if(tools.isNotEmpty()) Text("Las herramientas se consideran en la calculadora por su costo por uso.",color=MaterialTheme.colorScheme.onSurfaceVariant)
    }},confirmButton={Button(onClick={scope.launch{db.productDao().clearRecipe(product.id);recipeState.forEach{db.productDao().insertMaterial(it)};onClose()}}){Text("Guardar receta")}},dismissButton={TextButton(onClick=onClose){Text("Cancelar")}})
}

@Composable
private fun Production(products:List<Product>,materials:List<InventoryItem>,db:AppDatabase,scope:CoroutineScope,padding:PaddingValues){
    var selected by remember{mutableStateOf(products.firstOrNull()?.id?:0)};var q by remember{mutableStateOf("1")};var menu by remember{mutableStateOf(false)}
    val ctx=LocalContext.current
    LazyColumn(Modifier.padding(padding).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{Text("Fabricar producto",style=MaterialTheme.typography.titleLarge);Text("Consume automáticamente los materiales de la receta y suma stock terminado.",color=MaterialTheme.colorScheme.onSurfaceVariant)}
        item{Box{OutlinedButton(onClick={menu=true},modifier=Modifier.fillMaxWidth()){Text(products.firstOrNull{it.id==selected}?.name?:"Elegir producto")};DropdownMenu(expanded=menu,onDismissRequest={menu=false}){products.forEach{p->DropdownMenuItem(text={Text(p.name)},onClick={selected=p.id;menu=false})}}}}
        item{OutlinedTextField(q,{q=it},label={Text("Cantidad a fabricar")},modifier=Modifier.fillMaxWidth(),singleLine=true)}
        item{Button(onClick={
            val qtyMade=q.toDoubleOrNull()?:0.0;val product=products.firstOrNull{it.id==selected}
            if(product==null||qtyMade<=0){Toast.makeText(ctx,"Elegí un producto y una cantidad válida",Toast.LENGTH_SHORT).show()}else scope.launch{val recipe=db.productDao().recipe(product.id);val insufficient=recipe.mapNotNull{r->val m=materials.firstOrNull{it.id==r.materialId};if(m!=null&&m.quantity<r.quantity*qtyMade) "${m.name} (faltan ${qty(r.quantity*qtyMade-m.quantity)})" else null};if(insufficient.isNotEmpty()){Toast.makeText(ctx,"Stock insuficiente: ${insufficient.joinToString()}",Toast.LENGTH_LONG).show()}else db.withTransaction{recipe.forEach{db.inventoryDao().changeQuantity(it.materialId,-it.quantity*qtyMade)};db.productDao().update(product.copy(stock=product.stock+qtyMade));val cost=(recipe.sumOf{r->materials.firstOrNull{it.id==r.materialId}?.unitCost?.times(r.quantity)?:0.0}+product.laborCost+product.otherCost)*qtyMade;db.movementDao().insert(Movement(type=MovementType.PRODUCTION,description="Producción: ${product.name}",amount=cost,productId=product.id,quantity=qtyMade,category="PRODUCCIÓN"));Toast.makeText(ctx,"Producción registrada",Toast.LENGTH_SHORT).show()}}
        },modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Build,null);Spacer(Modifier.width(6.dp));Text("Registrar producción")}}
    }
}

@Composable
private fun Sales(products:List<Product>,db:AppDatabase,scope:CoroutineScope,padding:PaddingValues){
    var selected=remember{mutableStateOf(products.firstOrNull()?.id?:0)};var q by remember{mutableStateOf("1")};var account by remember{mutableStateOf(Account.EFECTIVO)};var menu by remember{mutableStateOf(false)};var accMenu by remember{mutableStateOf(false)}
    val ctx=LocalContext.current
    LazyColumn(Modifier.padding(padding).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{Text("Registrar venta",style=MaterialTheme.typography.titleLarge);Text("La venta descuenta stock del producto y registra el ingreso en la cuenta elegida.",color=MaterialTheme.colorScheme.onSurfaceVariant)}
        item{Box{OutlinedButton(onClick={menu=true},modifier=Modifier.fillMaxWidth()){Text(products.firstOrNull{it.id==selected.value}?.name?:"Elegir producto")};DropdownMenu(expanded=menu,onDismissRequest={menu=false}){products.forEach{p->DropdownMenuItem(text={Text("${p.name} • ${money(p.salePrice)}")},onClick={selected.value=p.id;menu=false})}}}}
        item{OutlinedTextField(q,{q=it},label={Text("Cantidad")},modifier=Modifier.fillMaxWidth(),singleLine=true)}
        item{Box{OutlinedButton(onClick={accMenu=true},modifier=Modifier.fillMaxWidth()){Text("Cobro: ${accountLabel(account)}")};DropdownMenu(expanded=accMenu,onDismissRequest={accMenu=false}){Account.values().forEach{a->DropdownMenuItem(text={Text(accountLabel(a))},onClick={account=a;accMenu=false})}}}}
        item{products.firstOrNull{it.id==selected.value}?.let{p->Card(colors=CardDefaults.cardColors(containerColor=Sage.copy(alpha=.3f))){Column(Modifier.padding(14.dp)){Text("Total venta",fontWeight=FontWeight.SemiBold);Text(money(p.salePrice*(q.toDoubleOrNull()?:0.0)),style=MaterialTheme.typography.headlineSmall)}}}}
        item{Button(onClick={val p=products.firstOrNull{it.id==selected.value};val count=q.toDoubleOrNull()?:0.0;if(p==null||count<=0)Toast.makeText(ctx,"Datos inválidos",Toast.LENGTH_SHORT).show() else if(p.stock<count)Toast.makeText(ctx,"Stock insuficiente (${qty(p.stock)} disponibles)",Toast.LENGTH_LONG).show() else scope.launch{db.withTransaction{db.productDao().update(p.copy(stock=p.stock-count));db.movementDao().insert(Movement(type=MovementType.SALE,description="Venta: ${p.name}",amount=p.salePrice*count,productId=p.id,quantity=count,account=account,category="VENTAS"))};Toast.makeText(ctx,"Venta registrada",Toast.LENGTH_SHORT).show()}},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.PointOfSale,null);Spacer(Modifier.width(6.dp));Text("Registrar venta")}}
    }
}

@Composable
private fun Tools(tools:List<InventoryItem>,db:AppDatabase,scope:CoroutineScope,padding:PaddingValues){
    var show by remember{mutableStateOf(false)}
    LazyColumn(Modifier.padding(padding).padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        item{Text("Herramientas y accesorios",style=MaterialTheme.typography.titleLarge);Text("Guardá valor y usos estimados. La app calcula el costo por uso para incorporarlo al precio.",color=MaterialTheme.colorScheme.onSurfaceVariant)}
        item{Button(onClick={show=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Add,null);Spacer(Modifier.width(6.dp));Text("Agregar herramienta")}}
        items(tools){t->InventoryRow(t);Text("Costo por uso: ${money(t.unitCost)}",modifier=Modifier.padding(start=16.dp,bottom=6.dp),color=MaterialTheme.colorScheme.onSurfaceVariant)}
    }
    if(show) ToolDialog(onDismiss={show=false}){t->scope.launch{db.inventoryDao().insert(t);show=false}}
}

@Composable
private fun PurchaseDialog(materials:List<InventoryItem>,onDismiss:()->Unit,onSave:(Long,Double,Double,String)->Unit){
    var id by remember{mutableStateOf(materials.firstOrNull()?.id?:0)};var amount by remember{mutableStateOf("")};var cost by remember{mutableStateOf("")};var desc by remember{mutableStateOf("Compra de materiales")};var menu by remember{mutableStateOf(false)}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Registrar compra")},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){Box{OutlinedButton(onClick={menu=true},modifier=Modifier.fillMaxWidth()){Text(materials.firstOrNull{it.id==id}?.name?:"Elegir material")};DropdownMenu(expanded=menu,onDismissRequest={menu=false}){materials.forEach{m->DropdownMenuItem(text={Text(m.name)},onClick={id=m.id;menu=false})}}};OutlinedTextField(amount,{amount=it},label={Text("Cantidad comprada")});OutlinedTextField(cost,{cost=it},label={Text("Costo por unidad")});OutlinedTextField(desc,{desc=it},label={Text("Descripción")})}},confirmButton={Button(onClick={if(id>0&&n(amount)>0)onSave(id,n(amount),n(cost),desc.ifBlank{"Compra de materiales"})}){Text("Registrar")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancelar")}})
}

@Composable
private fun LossDialog(materials:List<InventoryItem>,onDismiss:()->Unit,onSave:(Long,Double,Double,String)->Unit){
    var id by remember{mutableStateOf(materials.firstOrNull()?.id?:0)};var amount by remember{mutableStateOf("")};var cost by remember{mutableStateOf(materials.firstOrNull()?.unitCost?.toString()?:"")};var desc by remember{mutableStateOf("Pérdida de material")};var menu by remember{mutableStateOf(false)}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Registrar pérdida")},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){Box{OutlinedButton(onClick={menu=true},modifier=Modifier.fillMaxWidth()){Text(materials.firstOrNull{it.id==id}?.name?:"Elegir material")};DropdownMenu(expanded=menu,onDismissRequest={menu=false}){materials.forEach{m->DropdownMenuItem(text={Text(m.name)},onClick={id=m.id;cost=m.unitCost.toString();menu=false})}}};OutlinedTextField(amount,{amount=it},label={Text("Cantidad perdida")});OutlinedTextField(cost,{cost=it},label={Text("Costo unitario")});OutlinedTextField(desc,{desc=it},label={Text("Motivo")})}},confirmButton={Button(onClick={val m=materials.firstOrNull{it.id==id};if(m!=null&&n(amount)>0&&m.quantity>=n(amount))onSave(id,n(amount),n(cost),desc.ifBlank{"Pérdida de material"})}){Text("Registrar")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancelar")}})
}

@Composable
private fun EditMaterialDialog(item:InventoryItem,onDismiss:()->Unit,onSave:(InventoryItem)->Unit,onDelete:(InventoryItem)->Unit){
    var name by remember{mutableStateOf(item.name)};var qty0 by remember{mutableStateOf(item.quantity.toString())};var min by remember{mutableStateOf(item.minimumStock.toString())};var cost by remember{mutableStateOf(item.unitCost.toString())};var unit by remember{mutableStateOf(item.unit)};var confirmDelete by remember{mutableStateOf(false)}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Editar material")},text={Column(verticalArrangement=Arrangement.spacedBy(6.dp)){OutlinedTextField(name,{name=it},label={Text("Nombre")});OutlinedTextField(qty0,{qty0=it},label={Text("Stock")});OutlinedTextField(min,{min=it},label={Text("Stock mínimo")});OutlinedTextField(cost,{cost=it},label={Text("Costo por unidad")});OutlinedTextField(unit,{unit=it},label={Text("Unidad")})}},confirmButton={Button(onClick={onSave(item.copy(name=name,quantity=n(qty0),minimumStock=n(min),unitCost=n(cost),unit=unit.ifBlank{"unidad"}))}){Text("Guardar")}},dismissButton={Row{TextButton(onClick={onDismiss}){Text("Cancelar")};TextButton(onClick={confirmDelete=true}){Text("Eliminar")}}})
    if(confirmDelete)AlertDialog(onDismissRequest={confirmDelete=false},title={Text("Eliminar material")},text={Text("Esta acción no se puede deshacer.")},confirmButton={Button(onClick={onDelete(item)}){Text("Eliminar")}},dismissButton={TextButton(onClick={confirmDelete=false}){Text("Cancelar")}})
}

@Composable private fun ToolDialog(onDismiss:()->Unit,onSave:(InventoryItem)->Unit){var name by remember{mutableStateOf("")};var value by remember{mutableStateOf("")};var uses by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Nueva herramienta")},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){OutlinedTextField(name,{name=it},label={Text("Nombre")});OutlinedTextField(value,{value=it},label={Text("Valor de compra")});OutlinedTextField(uses,{uses=it},label={Text("Usos estimados")})}},confirmButton={Button(enabled=name.isNotBlank(),onClick={val v=n(value);val u=uses.toDoubleOrNull()?:1.0;onSave(InventoryItem(name=name,type=ItemType.TOOL,unit="uso",quantity=u,minimumStock=0.0,unitCost=if(u>0)v/u else 0.0,notes="Valor compra: $v; usos estimados: $u"))}){Text("Guardar")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancelar")}})}

@Composable
private fun Calculator(products:List<Product>,materials:List<InventoryItem>,tools:List<InventoryItem>,db:AppDatabase,scope:CoroutineScope,padding:PaddingValues){
    var selected by remember{mutableStateOf(products.firstOrNull()?.id?:0)};var menu by remember{mutableStateOf(false)};var units by remember{mutableStateOf("1")};var desiredMargin by remember{mutableStateOf("")};var cost by remember{mutableStateOf(0.0)};var suggested by remember{mutableStateOf(0.0)};var recipe by remember{mutableStateOf(emptyList<ProductMaterial>())}
    LaunchedEffect(selected,products,materials){products.firstOrNull{it.id==selected}?.let{p->recipe=db.productDao().recipe(p.id);val materialCost=recipe.sumOf{r->materials.firstOrNull{it.id==r.materialId}?.unitCost?.times(r.quantity)?:0.0};cost=materialCost+p.laborCost+p.otherCost;suggested=if(p.marginPercent<100)cost/(1-p.marginPercent/100.0) else cost}}
    LazyColumn(Modifier.padding(padding).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{Text("Calculadora de precios",style=MaterialTheme.typography.titleLarge);Text("Materiales + mano de obra + otros costos + margen.",color=MaterialTheme.colorScheme.onSurfaceVariant)}
        item{Box{OutlinedButton(onClick={menu=true},modifier=Modifier.fillMaxWidth()){Text(products.firstOrNull{it.id==selected}?.name?:"Elegir producto")};DropdownMenu(expanded=menu,onDismissRequest={menu=false}){products.forEach{p->DropdownMenuItem(text={Text(p.name)},onClick={selected=p.id;menu=false})}}}}
        item{OutlinedTextField(units,{units=it},label={Text("Cantidad")},modifier=Modifier.fillMaxWidth())}
        item{OutlinedTextField(desiredMargin,{desiredMargin=it},label={Text("Margen deseado % (opcional)")},modifier=Modifier.fillMaxWidth())}
        item{Card(colors=CardDefaults.cardColors(containerColor=Lavender)){Column(Modifier.padding(16.dp)){Text("Costo unitario",fontWeight=FontWeight.SemiBold);Text(money(cost),style=MaterialTheme.typography.headlineSmall);Text("Precio sugerido: ${money(if(desiredMargin.toDoubleOrNull()!=null&&desiredMargin.toDouble()<100)cost/(1-desiredMargin.toDouble()/100) else suggested)}");Text("Para ${qty(units.toDoubleOrNull()?:0.0)} unidad(es): ${money(cost*(units.toDoubleOrNull()?:0.0))}")}}}
        item{SectionTitle("Detalle")}
        item{recipe.forEach{r->Text("• ${materials.firstOrNull{it.id==r.materialId}?.name?:("Material "+r.materialId)}: ${qty(r.quantity)}")};Text("• Mano de obra: ${money(products.firstOrNull{it.id==selected}?.laborCost?:0.0)}");Text("• Otros costos: ${money(products.firstOrNull{it.id==selected}?.otherCost?:0.0)}")}
    }
}

@Composable
private fun Reports(income:Double,expenses:Double,movements:List<Movement>,low:List<InventoryItem>,products:List<Product>,padding:PaddingValues){
    val sales=movements.filter{it.type==MovementType.SALE}.sumOf{it.amount};val purchases=movements.filter{it.type==MovementType.MATERIAL_PURCHASE}.sumOf{it.amount};val losses=movements.filter{it.type==MovementType.LOSS}.sumOf{it.amount}
    LazyColumn(Modifier.padding(padding).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{Text("Resumen del negocio",style=MaterialTheme.typography.titleLarge);Text("Indicadores de la información registrada en el teléfono.",color=MaterialTheme.colorScheme.onSurfaceVariant)}
        item{MetricCard("Ventas",money(sales),Sage.copy(alpha=.55f),Modifier.fillMaxWidth())};item{MetricCard("Compras de materiales",money(purchases),Butter,Modifier.fillMaxWidth())};item{MetricCard("Pérdidas registradas",money(losses),Blush,Modifier.fillMaxWidth())};item{MetricCard("Resultado de caja",money(income-expenses),Lavender,Modifier.fillMaxWidth())}
        item{SectionTitle("Alertas");Text(if(low.isEmpty())"No hay insumos bajo el mínimo." else "${low.size} insumo(s) bajo el mínimo.")}
        item{SectionTitle("Stock de productos");products.forEach{Text("• ${it.name}: ${qty(it.stock)} unidades")}}
        item{SectionTitle("Movimientos recientes")};items(movements.take(100)){MovementRow(it)}
    }
}

@Composable
private fun Notes(ctx:Context,padding:PaddingValues){
    val prefs=remember{ctx.getSharedPreferences("notas",Context.MODE_PRIVATE)};var text by remember{mutableStateOf(prefs.getString("text","")?:"")};var saved by remember{mutableStateOf(false)}
    Column(Modifier.padding(padding).padding(16.dp).fillMaxSize(),verticalArrangement=Arrangement.spacedBy(10.dp)){
        Text("Notas del emprendimiento",style=MaterialTheme.typography.titleLarge);Text("Ideas, pendientes, proveedores, recordatorios y cualquier dato útil.",color=MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedTextField(text,{text=it;saved=false},modifier=Modifier.fillMaxSize().weight(1f),label={Text("Escribí tus notas")})
        Button(onClick={prefs.edit().putString("text",text).apply();saved=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Save,null);Spacer(Modifier.width(6.dp));Text(if(saved)"Guardado" else "Guardar notas")}
    }
}

@Composable private fun Settings(padding:PaddingValues){LazyColumn(Modifier.padding(padding).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("Configuración",style=MaterialTheme.typography.titleLarge)};item{InfoCard("Moneda","Peso chileno (CLP)")};item{InfoCard("Guardado","La base de datos se guarda automáticamente en el dispositivo.")};item{InfoCard("Versión","Mi Emprendimiento 1.1")};item{Text("Próximas evoluciones: respaldos/exportación, filtros por fechas, clientes/proveedores, categorías personalizadas y gráficos avanzados.",color=MaterialTheme.colorScheme.onSurfaceVariant)}}}

@Composable private fun InfoCard(a:String,b:String){Card(colors=CardDefaults.cardColors(containerColor=Color.White),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(a,fontWeight=FontWeight.SemiBold);Text(b,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}
@Composable private fun SectionTitle(text:String){Text(text,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.SemiBold)}

@Composable
private fun MaterialDialog(onDismiss:()->Unit,onSave:(InventoryItem)->Unit){var name by remember{mutableStateOf("")};var qty by remember{mutableStateOf("")};var min by remember{mutableStateOf("")};var cost by remember{mutableStateOf("")};var unit by remember{mutableStateOf("unidad")};var supplier by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Nuevo material")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)){OutlinedTextField(name,{name=it},label={Text("Nombre")});OutlinedTextField(qty,{qty=it},label={Text("Stock inicial")});OutlinedTextField(min,{min=it},label={Text("Stock mínimo")});OutlinedTextField(cost,{cost=it},label={Text("Costo por unidad")});OutlinedTextField(unit,{unit=it},label={Text("Unidad")});OutlinedTextField(supplier,{supplier=it},label={Text("Proveedor (opcional)")})}},confirmButton={Button(enabled=name.isNotBlank(),onClick={onSave(InventoryItem(name=name,type=ItemType.MATERIAL,unit=unit.ifBlank{"unidad"},quantity=n(qty),minimumStock=n(min),unitCost=n(cost),supplier=supplier))}){Text("Guardar")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancelar")}})}

@Composable
private fun <T> SimpleChoiceDialog(title:String,values:List<T>,label:(T)->String,onDismiss:()->Unit,onChoose:(T)->Unit){AlertDialog(onDismissRequest=onDismiss,title={Text(title)},text={Column{values.forEach{v->TextButton(onClick={onChoose(v)},modifier=Modifier.fillMaxWidth()){Text(label(v))}}}},confirmButton={})}

fun accountLabel(a:Account)=when(a){Account.EFECTIVO->"Efectivo";Account.CAJA_CHICA->"Caja chica";Account.BANCO->"Cuenta bancaria"}
fun money(value:Double):String="$"+String.format(Locale("es","CL"),"%,.0f",value)
fun qty(v:Double):String=if(v%1.0==0.0)String.format(Locale("es","CL"),"%.0f",v) else String.format(Locale("es","CL"),"%.2f",v)
fun n(s:String)=s.replace(".","").replace(",","").toDoubleOrNull()?:0.0
fun date(ms:Long)=SimpleDateFormat("dd/MM/yyyy HH:mm",Locale("es","CL")).format(Date(ms))

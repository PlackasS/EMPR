package com.emprendimiento.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class MovementType { INCOME, EXPENSE, MATERIAL_PURCHASE, PRODUCTION, SALE, LOSS, TRANSPORT, OTHER_COST }
enum class ItemType { MATERIAL, TOOL, PRODUCT }
enum class Account { EFECTIVO, CAJA_CHICA, BANCO }

@Entity
data class InventoryItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: ItemType,
    val unit: String,
    val quantity: Double = 0.0,
    val minimumStock: Double = 0.0,
    val unitCost: Double = 0.0,
    val supplier: String = "",
    val notes: String = ""
)

@Entity
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val salePrice: Double = 0.0,
    val laborCost: Double = 0.0,
    val otherCost: Double = 0.0,
    val stock: Double = 0.0,
    val marginPercent: Double = 30.0,
    val notes: String = ""
)

@Entity
data class ProductMaterial(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val materialId: Long,
    val quantity: Double
)

@Entity
data class Movement(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: MovementType,
    val description: String,
    val amount: Double,
    val dateMillis: Long = System.currentTimeMillis(),
    val inventoryItemId: Long? = null,
    val productId: Long? = null,
    val quantity: Double? = null,
    val account: Account = Account.EFECTIVO,
    val category: String = "OTRO",
    val notes: String = ""
)

package com.emprendimiento.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [InventoryItem::class, Product::class, ProductMaterial::class, Movement::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun inventoryDao(): InventoryDao
    abstract fun productDao(): ProductDao
    abstract fun movementDao(): MovementDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE Product ADD COLUMN stock REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE Product ADD COLUMN marginPercent REAL NOT NULL DEFAULT 30.0")
                db.execSQL("ALTER TABLE Movement ADD COLUMN account TEXT NOT NULL DEFAULT 'EFECTIVO'")
                db.execSQL("ALTER TABLE Movement ADD COLUMN category TEXT NOT NULL DEFAULT 'OTRO'")
            }
        }
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "emprendimiento.db")
                .addMigrations(MIGRATION_1_2).build().also { INSTANCE = it }
        }
    }
}

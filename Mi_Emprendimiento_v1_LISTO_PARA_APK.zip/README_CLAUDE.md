# MI EMPRENDIMIENTO — ESPECIFICACIÓN MAESTRA v1.0

Este proyecto es la base de una aplicación Android para administrar la economía e inventario de un emprendimiento.

## OBJETIVO
Crear una app instalable en Android, sencilla y agradable, con colores pastel suaves. Todos los módulos deben estar relacionados para evitar doble registro.

## MÓDULOS

### 1. Usuarios
- Usuario y contraseña.
- Sesión persistente.
- Preparar arquitectura para varios emprendimientos/usuarios.
- No guardar contraseñas en texto plano en producción.

### 2. Finanzas
Movimientos:
- Ingreso
- Gasto
- Compra de material
- Transporte
- Pérdida
- Otro costo
- Venta
Cada movimiento: fecha, descripción, monto, categoría, notas y vínculos con inventario/producto cuando corresponda.

### 3. Inventario
Tipos:
- Material/insumo
- Herramienta
- Producto terminado
Campos: nombre, unidad, cantidad, stock mínimo, costo unitario, proveedor, notas.
Al bajar a stock mínimo: alerta visible y notificación Android.

### 4. Productos y recetas
Crear producto con:
- nombre
- precio de venta sugerido
- materiales necesarios
- cantidad de cada material
- mano de obra
- transporte
- pérdidas
- otros costos

Costo unitario = materiales consumidos + mano de obra + transporte + pérdidas + otros costos.

### 5. Producción
Al fabricar N unidades:
- descontar automáticamente los materiales de inventario;
- crear N unidades de producto terminado;
- registrar movimiento de producción;
- calcular costo real;
- alertar si algún material queda bajo el mínimo.
Nunca permitir stock negativo sin confirmación explícita.

### 6. Ventas
Al registrar venta:
- ingreso financiero;
- descuento de producto terminado;
- costo de venta basado en costo de fabricación;
- cálculo de margen/ganancia;
- historial relacionado.

### 7. Pérdidas
Permitir registrar pérdida de material:
- material afectado
- cantidad perdida
- motivo
- costo calculado
- fecha/notas
Esto debe descontar inventario y registrar costo.

### 8. Compras
Compra de insumos:
- proveedor
- material
- cantidad
- costo unitario
- costo total
- transporte asociado
La compra debe generar gasto y entrada de inventario.

### 9. Herramientas
Registrar herramientas separadamente de insumos. No se consumen al fabricar. Campos: nombre, cantidad, costo, fecha, estado, notas.

### 10. Dashboard
Mostrar:
- ingresos
- gastos/costos
- ganancia
- valor estimado de inventario
- productos terminados
- alertas de stock bajo
- movimientos recientes.

### 11. Informes
Preparar:
- diario, semanal, mensual, anual;
- ingresos vs costos;
- ganancias;
- gastos por categoría;
- consumo de materiales;
- costo y margen por producto;
- pérdidas;
- valor de inventario.

## REGLAS DE NEGOCIO IMPORTANTES
1. Una compra de material puede crear simultáneamente gasto + entrada de inventario.
2. Una producción crea consumo de materiales + entrada de producto terminado + costo de producción.
3. Una venta crea ingreso + salida de producto + costo de venta + margen.
4. Una pérdida crea salida de inventario + costo de pérdida.
5. Transporte puede asociarse a compras, ventas o producción.
6. No duplicar movimientos manualmente.
7. Mantener trazabilidad: cada movimiento debe poder indicar qué operación lo originó.
8. Usar Decimal/BigDecimal o Long en centavos para dinero; evitar Double para cálculos monetarios en producción.
9. Usar transacciones de base de datos para operaciones que cambian varios registros.
10. Preparar migraciones de Room desde el inicio.

## DISEÑO
Paleta:
- Fondo crema #F8F4EE
- Verde salvia #B7D5C2
- Verde oscuro #668B76
- Rosa empolvado #F0D8DE
- Lavanda #E4DDF0
- Amarillo mantequilla #F3E7C8
- Texto #3F4843

Estilo:
- tarjetas redondeadas
- botones claros
- iconografía simple
- buena legibilidad
- interfaz en español
- moneda inicial: CLP, configurable después

## SIGUIENTE TRABAJO PARA CLAUDE
Usar este proyecto como base y completar:
1. navegación completa;
2. login y sesión;
3. CRUD de materiales, herramientas y productos;
4. editor visual de recetas;
5. producción con consumo automático;
6. compras vinculadas a finanzas;
7. ventas vinculadas a inventario;
8. pérdidas y transporte;
9. alertas y notificaciones;
10. informes y filtros;
11. validaciones;
12. pruebas unitarias;
13. exportación/copia de seguridad;
14. generación de APK debug y release.

NO eliminar las relaciones entre módulos para simplificar la implementación. La prioridad es mantener integridad de inventario y trazabilidad financiera.

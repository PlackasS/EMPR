package com.emprendimiento.app.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Cream = Color(0xFFF8F4EE)
val Sage = Color(0xFFB7D5C2)
val SageDark = Color(0xFF668B76)
val Blush = Color(0xFFF0D8DE)
val Lavender = Color(0xFFE4DDF0)
val Butter = Color(0xFFF3E7C8)
val Ink = Color(0xFF3F4843)

private val LightColors = lightColorScheme(
    primary = SageDark,
    onPrimary = Color.White,
    secondary = Color(0xFF9D7180),
    background = Cream,
    surface = Color(0xFFFFFCF8),
    onBackground = Ink,
    onSurface = Ink
)

@Composable
fun EmprendimientoTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LightColors, content = content)
}

package com.emprendimiento.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.emprendimiento.app.data.*
import com.emprendimiento.app.ui.theme.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(this)
        setContent { EmprendimientoTheme { App(db) } }
    }
}

@Composable
fun App(db: AppDatabase) {
    var screen by remember { mutableStateOf("home") }
    val scope = rememberCoroutineScope()
    val items by db.inventoryDao().observeAll().collectAsState(initial = emptyList())
    val low by db.inventoryDao().observeLowStock().collectAsState(initial = emptyList())
    val products by db.productDao().observeAll().collectAsState(initial = emptyList())
    val movements by db.movementDao().observeAll().collectAsState(initial = emptyList())
    val income by db.movementDao().observeIncome().collectAsState(initial = 0.0)
    val expenses by db.movementDao().observeExpenses().collectAsState(initial = 0.0)

    Scaffold(
        containerColor = Cream,
        bottomBar = {
            NavigationBar(containerColor = Cream) {
                listOf("home" to "Inicio", "finance" to "Finanzas", "stock" to "Inventario",
                    "production" to "Producción", "reports" to "Informes").forEach { (key, label) ->
                    NavigationBarItem(selected = screen == key, onClick = { screen = key },
                        icon = {}, label = { Text(label) })
                }
            }
        }
    ) { padding ->
        when (screen) {
            "home" -> Home(income, expenses, low.size, products.size, padding)
            "finance" -> Finance(movements, scope, db, padding)
            "stock" -> Stock(items, scope, db, padding)
            "production" -> Production(products, items, scope, db, padding)
            else -> Reports(income, expenses, movements, padding)
        }
    }
}

@Composable
fun Home(income: Double, expenses: Double, alerts: Int, products: Int, padding: PaddingValues) {
    LazyColumn(Modifier.padding(padding).padding(18.dp)) {
        item {
            Text("Mi Emprendimiento 🌿", style = MaterialTheme.typography.headlineMedium)
            Text("Resumen general", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(18.dp))
            SummaryCard("Ingresos", money(income), Sage.copy(alpha=.55f))
            SummaryCard("Gastos y costos", money(expenses), Blush)
            SummaryCard("Ganancia", money(income - expenses), Lavender)
            SummaryCard("Productos", products.toString(), Butter)
            if (alerts > 0) Text("⚠️ $alerts insumo(s) con stock bajo",
                modifier = Modifier.padding(top = 12.dp),
                color = MaterialTheme.colorScheme.error)
        }
    }
}

@Composable fun SummaryCard(title: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Card(Modifier.fillMaxWidth().padding(bottom = 10.dp), colors = CardDefaults.cardColors(containerColor = color)) {
        Column(Modifier.padding(18.dp)) { Text(title); Text(value, style = MaterialTheme.typography.headlineSmall) }
    }
}

@Composable
fun Finance(movements: List<Movement>, scope: kotlinx.coroutines.CoroutineScope, db: AppDatabase, padding: PaddingValues) {
    var description by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    LazyColumn(Modifier.padding(padding).padding(18.dp)) {
        item {
            Text("Finanzas", style = MaterialTheme.typography.headlineMedium)
            OutlinedTextField(description, { description = it }, label = { Text("Descripción") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(amount, { amount = it }, label = { Text("Monto") }, modifier = Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                Button(onClick = {
                    amount.toDoubleOrNull()?.let { a ->
                        scope.launch { db.movementDao().insert(Movement(type=MovementType.INCOME, description=description, amount=a)) }
                        description = ""; amount = ""
                    }
                }) { Text("Agregar ingreso") }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = {
                    amount.toDoubleOrNull()?.let { a ->
                        scope.launch { db.movementDao().insert(Movement(type=MovementType.EXPENSE, description=description, amount=a)) }
                        description = ""; amount = ""
                    }
                }) { Text("Agregar gasto") }
            }
            HorizontalDivider()
        }
        items(movements.take(50)) { m ->
            ListItem(headlineContent = { Text(m.description) },
                supportingContent = { Text(m.type.name) },
                trailingContent = { Text(money(m.amount)) })
        }
    }
}

@Composable
fun Stock(items: List<InventoryItem>, scope: kotlinx.coroutines.CoroutineScope, db: AppDatabase, padding: PaddingValues) {
    var name by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("") }
    var min by remember { mutableStateOf("") }
    LazyColumn(Modifier.padding(padding).padding(18.dp)) {
        item {
            Text("Inventario", style = MaterialTheme.typography.headlineMedium)
            Text("Materiales, insumos, herramientas y productos")
            OutlinedTextField(name, { name=it }, label={ Text("Nombre") }, modifier=Modifier.fillMaxWidth())
            OutlinedTextField(qty, { qty=it }, label={ Text("Cantidad inicial") }, modifier=Modifier.fillMaxWidth())
            OutlinedTextField(min, { min=it }, label={ Text("Stock mínimo") }, modifier=Modifier.fillMaxWidth())
            Button(onClick={
                if(name.isNotBlank()) scope.launch {
                    db.inventoryDao().insert(InventoryItem(name=name, type=ItemType.MATERIAL,
                        unit="unidad", quantity=qty.toDoubleOrNull() ?: 0.0, minimumStock=min.toDoubleOrNull() ?: 0.0))
                    name=""; qty=""; min=""
                }
            }, modifier=Modifier.padding(vertical=8.dp)) { Text("Agregar insumo") }
            HorizontalDivider()
        }
        items(items) { item ->
            ListItem(headlineContent={ Text(item.name) },
                supportingContent={ Text("${item.quantity} ${item.unit} • mínimo ${item.minimumStock}") },
                trailingContent={ if(item.minimumStock > 0 && item.quantity <= item.minimumStock) Text("⚠️") })
        }
    }
}

@Composable
fun Production(products: List<Product>, inventory: List<InventoryItem>, scope: kotlinx.coroutines.CoroutineScope, db: AppDatabase, padding: PaddingValues) {
    var name by remember { mutableStateOf("") }
    var labor by remember { mutableStateOf("") }
    var sale by remember { mutableStateOf("") }
    LazyColumn(Modifier.padding(padding).padding(18.dp)) {
        item {
            Text("Producción", style=MaterialTheme.typography.headlineMedium)
            Text("Productos, recetas, mano de obra y costos adicionales")
            OutlinedTextField(name,{name=it},label={Text("Nombre del producto")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(labor,{labor=it},label={Text("Costo de mano de obra")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(sale,{sale=it},label={Text("Precio de venta")},modifier=Modifier.fillMaxWidth())
            Button(onClick={
                if(name.isNotBlank()) scope.launch {
                    val id=db.productDao().insert(Product(name=name,laborCost=labor.toDoubleOrNull()?:0.0,salePrice=sale.toDoubleOrNull()?:0.0))
                    // La receta de materiales se agregará en la siguiente iteración de la UI.
                    name=""; labor=""; sale=""
                }
            }) { Text("Crear producto") }
            Spacer(Modifier.height(10.dp))
            Text("Productos creados", style=MaterialTheme.typography.titleLarge)
        }
        items(products) { p ->
            ListItem(headlineContent={Text(p.name)},
                supportingContent={Text("Mano de obra: ${money(p.laborCost)} • Venta: ${money(p.salePrice)}")})
        }
    }
}

@Composable
fun Reports(income: Double, expenses: Double, movements: List<Movement>, padding: PaddingValues) {
    LazyColumn(Modifier.padding(padding).padding(18.dp)) {
        item {
            Text("Informes", style=MaterialTheme.typography.headlineMedium)
            SummaryCard("Ingresos", money(income), Sage.copy(alpha=.55f))
            SummaryCard("Costos / gastos", money(expenses), Blush)
            SummaryCard("Resultado", money(income-expenses), Lavender)
            Text("Total de movimientos: ${movements.size}", style=MaterialTheme.typography.titleMedium)
            Text("La versión siguiente incorporará filtros por fecha, categorías y gráficos.")
        }
    }
}

fun money(value: Double): String = "$" + "%,.0f".format(java.util.Locale("es", "CL"), value)

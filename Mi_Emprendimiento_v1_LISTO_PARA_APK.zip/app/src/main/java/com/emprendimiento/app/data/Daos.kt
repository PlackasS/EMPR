package com.emprendimiento.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface InventoryDao {
    @Query("SELECT * FROM InventoryItem ORDER BY name")
    fun observeAll(): Flow<List<InventoryItem>>

    @Query("SELECT * FROM InventoryItem WHERE quantity <= minimumStock AND minimumStock > 0 ORDER BY name")
    fun observeLowStock(): Flow<List<InventoryItem>>

    @Insert suspend fun insert(item: InventoryItem): Long
    @Update suspend fun update(item: InventoryItem)
    @Delete suspend fun delete(item: InventoryItem)

    @Query("UPDATE InventoryItem SET quantity = quantity + :delta WHERE id = :id")
    suspend fun changeQuantity(id: Long, delta: Double)

    @Query("SELECT * FROM InventoryItem WHERE id = :id LIMIT 1")
    suspend fun get(id: Long): InventoryItem?
}

@Dao
interface ProductDao {
    @Query("SELECT * FROM Product ORDER BY name")
    fun observeAll(): Flow<List<Product>>
    @Insert suspend fun insert(product: Product): Long
    @Update suspend fun update(product: Product)
    @Delete suspend fun delete(product: Product)
    @Insert suspend fun insertMaterial(recipe: ProductMaterial)
    @Query("SELECT * FROM ProductMaterial WHERE productId = :productId")
    suspend fun recipe(productId: Long): List<ProductMaterial>
}

@Dao
interface MovementDao {
    @Query("SELECT * FROM Movement ORDER BY dateMillis DESC")
    fun observeAll(): Flow<List<Movement>>
    @Insert suspend fun insert(movement: Movement): Long

    @Query("SELECT COALESCE(SUM(amount),0) FROM Movement WHERE type IN ('INCOME','SALE')")
    fun observeIncome(): Flow<Double>

    @Query("SELECT COALESCE(SUM(amount),0) FROM Movement WHERE type IN ('EXPENSE','MATERIAL_PURCHASE','LOSS','TRANSPORT','OTHER_COST')")
    fun observeExpenses(): Flow<Double>
}

# Mi Emprendimiento — compilar APK

Este proyecto está preparado para compilarse mediante GitHub Actions sin instalar Android Studio.

## Qué genera
El flujo genera:

    app/build/outputs/apk/debug/app-debug.apk

Es un APK debug instalable directamente en un teléfono Android para pruebas.

## Requisitos
- Una cuenta de GitHub.
- Crear un repositorio y subir TODO el contenido de este proyecto.
- No hace falta instalar Gradle ni Android Studio en el computador/teléfono.

## Compilación
1. Crea un repositorio en GitHub.
2. Sube el contenido de este ZIP manteniendo las carpetas.
3. Abre la pestaña `Actions`.
4. Selecciona `Compilar APK`.
5. Pulsa `Run workflow`.
6. Cuando termine correctamente, abre la ejecución.
7. En `Artifacts`, descarga `Mi-Emprendimiento-debug-apk`.
8. Descomprime el archivo descargado y tendrás `app-debug.apk`.
9. Instálalo en Android.

## Importante
Este proyecto usa Android Gradle Plugin 8.7.3 y Kotlin 2.0.21.
El workflow usa Gradle 8.9 y Java 17.

Para las próximas modificaciones, conserva este repositorio como proyecto principal.
Los cambios de código pueden hacerse desde ChatGPT y luego subirse al repositorio para volver
a compilar una nueva versión.

El APK debug no es una versión firmada para publicar en Google Play. Para instalarlo
personalmente en tu teléfono, es suficiente.
